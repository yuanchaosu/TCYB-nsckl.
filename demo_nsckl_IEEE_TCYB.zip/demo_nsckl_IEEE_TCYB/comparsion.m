clc
clear all
close all
currentFolder = pwd;
addpath(genpath(currentFolder))
load Indian % Hyperspectral image
load Indian_gt % Ground Truth
test = 1;
[Para] = HyParameters(test);
C=[10^0 10^1 10^2 10^3 10^4 10^5]; % Regularization parameters for KELM 
sigma0=[2^(-4),2^(-3),2^(-2),2^(-1),2^(0),2^(1),2^(2),2^(3),2^(4)]; % Regularization parameters for KELM 
classifier = 'KELM';
classnum = 16;
runtimes = 10;
samp_perc = 0.1;% percentage of training samples 
n_segment = 0;

gamma01 = [0.05,0.1,0.15,0.2,0.25,0.3];
n_anchors01 = [50,60,70,100,150,200]; % achor node
%%
for i = 1:length(gamma01)
    for j = 1:length(n_anchors01)
    gamma0 = gamma01(i);
    n_anchors = n_anchors01(j);
    [B,labels,pred1,OA1,AA1,kappa1,CA1,TIME] = NSCKL_classifi_Random(image,GT,classifier,Para.clus,...
    Para.winw,Para.gamma0,Para.lambad0,Para.T,Para.n_random_anchors,C,sigma0,classnum,runtimes,...
    samp_perc,'yes','no');
    OA = mean(OA1);
    AA = mean(AA1);
    OA_T(j,i) = OA;
    AA_T(j,i) = AA;
    end
end

OA_T1 = OA_T*100; AA_T1 = AA_T*100;
%%
figure(1)
surf(gamma01,n_anchors01,OA_T1);
colormap(summer)
set(gca,'FontSize',15);
xlabel('\gamma','fontsize',18);
ylabel('Anchors','fontsize',18);
zlabel('OA (%)','fontsize',18);
set(gcf, 'position', [400 400 500 300]);
figure(2)
surf(gamma01,n_anchors01,AA_T1);
colormap(winter)
set(gca,'FontSize',15);
xlabel('\gamma','fontsize',18);
ylabel('Anchors','fontsize',18);
zlabel('AA (%)','fontsize',18);
set(gcf, 'position', [400 400 500 300]);

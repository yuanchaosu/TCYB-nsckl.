function [U] = normalized(X)
% Regularization
%%
min_value = min(X);
X = X-min_value;
max_value = max(X);
U = X./max_value;
end
% The purpose of this demo is to conduct academic communication. 
% The demo may not be commercialized without the permission of the developer.
%
% Authors: Yuanchao Su, Mengying Jiang, Lianru Gao, Antonio Plaza, Xu Sun, and Bing Zhang.
% Beijing, China
% 2021
%
% Email(Yuanchao Su): suych3@xust.edu.cn
% Email(Lianru Gao): gaolr@aircas.ac.cn
%%
clc
clear all
close all
currentFolder = pwd;
addpath(genpath(currentFolder))
%%
% test = 1: Experiment with Indian Pines data (Classification map with ground-truth)
% test = 2: Experiment with Indian Pines data (Classification map with whole image)
% test = 3: Experiments with Salinas data
% test = 4: Experiments with Houston University data (Classification map with whole image)
% test = 5: Experiments with Houston University data (Classification map with ground-truth)
% test = 6: Experiments with WHU-Hi-LongKou data
test = 1;
%%
switch test
    case 1
        load Indian % Hyperspectral image
        load Indian_gt % Ground Truth
        [Para] = HyParameters(test);

        C=[10^0 10^1 10^2 10^3 10^4 10^5]; % Regularization parameters for KELM 
        sigma0=[2^(-4),2^(-3),2^(-2),2^(-1),2^(0),2^(1),2^(2),2^(3),2^(4)]; % Regularization parameters for KELM 
% classifier: (1) KELM and (2) Mutilayer KELM(ML_KELM)
        classifier = 'KELM';
% classifier = 'ML_KELM';
        classnum = 16;
        runtimes = 10;
        samp_perc = 0.1;% percentage of training samples 
        n_segment = 0;
% NSCKL for semisupervised classification
        [B,labels,pred1,OA1,AA1,kappa1,CA1,TIME] = NSCKL_classifi_Random(image,GT,classifier,Para.clus,...
         Para.winw,Para.gamma0,Para.lambad0,Para.T,Para.n_random_anchors,C,sigma0,classnum,runtimes,...
        samp_perc,'yes','yes');
%% Take the tenth precision, take the mean and the standard deviation.
        OA = mean(OA1)
        std_OA = std(OA1)
        AA = mean(AA1)
        std_AA = std(AA1)
        KAPPA = mean( kappa1)
        std_KAPPA = std( kappa1)
        CA1 = CA1';
        CA = mean(CA1)
        std_CA = std(CA1)
        time = mean(TIME)
        stdtime = std(TIME)
%%
% classifictaion map
figure('NumberTitle', 'off', 'Name', 'Classification Performance')
idx0 = find(GT == 0);
GT(idx0) = nan;
idx = find(pred1 == 0);
pred1(idx) = nan;
subplot(1,2,1);
h0 = imagesc(GT);
colormap(jet)
title ('Ground Truth')
set(h0,'alphadata',~isnan(GT));
axis off
subplot(1,2,2);
h1 = imagesc(pred1);
colormap(jet)
set(h1,'alphadata',~isnan(pred1));
title ('NSCKL')
axis off
set(gcf, 'position', [400 400 500 200]);
   case 2
      load Indian % Hyperspectral image
      load Indian_gt % Ground Truth
      [Para] = HyParameters(test);
      C=[10^0 10^1 10^2 10^3 10^4 10^5]; % Regularization parameters for KELM 
      sigma0=[2^(-4),2^(-3),2^(-2),2^(-1),2^(0),2^(1),2^(2),2^(3),2^(4)]; % Regularization parameters for KELM 
% classifier: (1) KELM and (2) Mutilayer KELM(ML_KELM)
      classifier = 'KELM';
% classifier = 'ML_KELM';
      classnum = 16;
      runtimes = 10;
      samp_perc = 0.1;% percentage of training samples 
      n_segment = 0;
% NSCKL for semisupervised classification
% Accuracy: Using 'yes' to implement accuracy calculation.
% Accuracy: Using 'no', all pixels will get their labels. The accuracy will be "0".
      [B,labels,pred1] = NSCKL_classifi_Random(image,GT,classifier,Para.clus,...
      Para.winw,Para.gamma0,Para.lambad0,Para.T,Para.n_random_anchors,C,sigma0,classnum,runtimes,...
      samp_perc,'no','no');
%%
% Visualization
% classifictaion map
figure('NumberTitle', 'off', 'Name', 'Semisupervised Result')
imagesc(pred1);
colormap(jet)
title ('Classification Map')
axis off
set(gcf, 'position', [500 500 250 200]);
   case 3
       load Salinas.mat
       load Salinas_gt.mat
       image = salinas;
       GT = salinas_gt;
       [Para] = HyParameters(test);
       C=[10^0 10^1 10^2 10^3 10^4 10^5]; % Regularization parameters for KELM 
       sigma0=[2^(-4),2^(-3),2^(-2),2^(-1),2^(0),2^(1),2^(2),2^(3),2^(4)];
       classifier = 'KELM';
% classifier = 'M_KELM'; 
       classnum = 16;
       runtimes = 10;
       samp_perc = 0.01;% percentage of training samples 
       n_segment = 0;
      [B,labels,pred1,OA1,AA1,kappa1,CA1,TIME] = NSCKL_classifi_Random(image,GT,classifier,Para.clus,...
       Para.winw,Para.gamma0,Para.lambad0,Para.T,Para.n_random_anchors,C,sigma0,classnum,runtimes,...
       samp_perc,'yes','no');
       OA = mean(OA1)
       std_OA = std(OA1)
       AA = mean(AA1)
       std_AA = std(AA1)
       KAPPA = mean( kappa1)
       std_KAPPA = std( kappa1)
       CA1 = CA1';
       CA = mean(CA1)
       std_CA = std(CA1)
       time = mean(TIME)
       stdtime = std(TIME)
%%
% Visualization
% classifictaion map
figure('NumberTitle', 'off', 'Name', 'Classification Performance')
idx0 = find(GT == 0);
GT(idx0) = nan;
idx = find(pred1 == 0);
pred1(idx) = nan;
subplot(1,2,1);
h0 = imagesc(GT);
colormap(jet)
title ('Ground Truth')
set(h0,'alphadata',~isnan(GT));
axis off
subplot(1,2,2);
h1 = imagesc(pred1);
colormap(jet)
set(h1,'alphadata',~isnan(pred1));
title ('NSCKL')
axis off
set(gcf, 'position', [400 400 500 350]);
   case 4
%%
% In Houston data, the training samples is invariable.
      load Houston.mat
      load Houston_gt.mat
      load Houston_train
      load Houston_test
      [Para] = HyParameters(test);
      C=[10^0 10^1 10^2 10^3 10^4 10^5];
      sigma0=[2^(-4),2^(-3),2^(-2),2^(-1),2^(0),2^(1),2^(2),2^(3),2^(4)];
      classifier = 'KELM'; 
      n_segment = 1000;
      classnum = 15;
      runtimes = 1;
      image = Houston;
      GT = Houston_gt;
% In Houston data, the training samples is invariable. 
% Classification accuracy can be shown by setting 'accuracy' as 'yes'
      [B,labels,pred1] = NSCKL_classifi_Given(image,GT,houston_train,houston_test,classifier,...
       Para.clus,Para.winw,Para.gamma0,Para.lambad0,Para.T,Para.n_random_anchors,C,sigma0,classnum,runtimes,'no','no');
%%    
% Visualization
% classifictaion map
% figure('NumberTitle', 'off', 'Name', 'Classification Map')
% imagesc(pred1);
% colormap(lines)
% axis off
% set(gcf, 'position', [400 400 1500 300]);


[nr,nc,bands] = size(image);
pred1(pred1==0)=16;
Pred1_show = Colors_Houston2013(pred1,nr,nc);
GT_new = GT;
GT_new(GT==0)=16;
GTnew = Colors_Houston2013(GT_new,nr,nc);

figure('NumberTitle', 'off', 'Name', 'Ground-Truth')
imshow(uint8(GTnew));
title ('Ground Truth')
axis off
set(gcf, 'position', [400 400 1500 300]);

figure('NumberTitle', 'off', 'Name', 'NSCKL')
imshow(uint8(Pred1_show));
title ('NSCKL')
axis off
set(gcf, 'position', [400 400 1500 300]);

   case 5
%%
% In Houston data, the training samples is invariable.
     load Houston.mat
     load Houston_gt.mat
     load Houston_train
     load Houston_test
     [Para] = HyParameters(test);
     C=[10^0 10^1 10^2 10^3 10^4 10^5];
     sigma0=[2^(-4),2^(-3),2^(-2),2^(-1),2^(0),2^(1),2^(2),2^(3),2^(4)];
     classifier = 'KELM'; 
     n_segment = 1000;
     classnum = 15;
     runtimes = 1;
     image = Houston;
     GT = Houston_gt;
% In Houston data, the training samples is invariable. 
% Classification accuracy can be shown by setting 'accuracy' as 'yes'
     [B,labels,pred1,OA1,AA1,kappa1] = NSCKL_classifi_Given(image,GT,houston_train,houston_test,classifier,...
     Para.clus,Para.winw,Para.gamma0,Para.lambad0,Para.T,Para.n_random_anchors,C,sigma0,classnum,runtimes,'yes','no');
     OA = mean(OA1)
     std_OA = std(OA1)
     AA = mean(AA1)
     std_AA = std(AA1)
     KAPPA = mean( kappa1)
     std_KAPPA = std( kappa1)
%%    
% Visualization
% classifictaion map
% figure('NumberTitle', 'off', 'Name', 'Classification Map')
% subplot(2,1,1);
% imagesc(GT);
% title ('Ground Truth')
% axis off
% subplot(2,1,2);
% imagesc(pred1);
% title ('NSCKL')
% axis off
% set(gcf, 'position', [300 300 1300 600]);
[nr,nc,bands] = size(image);
pred1(pred1==0)=16;
Pred1_show = Colors_Houston2013(pred1,nr,nc);
GT_new = GT;
GT_new(GT==0)=16;
GTnew = Colors_Houston2013(GT_new,nr,nc);
figure('NumberTitle', 'off', 'Name', 'Classification Map')
subplot(2,1,1);
imshow(uint8(GTnew));
title ('Ground Truth')
axis off
subplot(2,1,2);
imshow(uint8(Pred1_show));
title ('NSCKL')
axis off
set(gcf, 'position', [300 300 1300 600]);

%% WuHan data sets
   case 6
      load WHU_Hi_LongKou
      load WHU_Hi_LongKou_gt
      image = WHU_Hi_LongKou;
      GT = WHU_Hi_LongKou_gt;
      [Para] = HyParameters(test);
      C=[10^0 10^1 10^2 10^3 10^4 10^5];
      sigma0=[2^(-4),2^(-3),2^(-2),2^(-1),2^(0),2^(1),2^(2),2^(3),2^(4)];
      classifier = 'KELM';
      classnum = 9;
      runtimes = 10;
      samp_perc = 0.01;% percentage of training samples
      n_segment = 100;
      [B,labels,pred1,OA1,AA1,kappa1,CA1,TIME] = NSCKL_classifi_Random(image,GT,classifier,Para.clus,...
      Para.winw,Para.gamma0,Para.lambad0,Para.T,Para.n_random_anchors,C,sigma0,classnum,runtimes,samp_perc,'yes','no');
      OA = mean(OA1)
      std_OA = std(OA1)
      AA = mean(AA1)
      std_AA = std(AA1)
      KAPPA = mean( kappa1)
      std_KAPPA = std( kappa1)
      CA1 = CA1';
      CA = mean(CA1)
      std_CA = std(CA1)
      time = mean(TIME)
      stdtime = std(TIME)
%%
figure('NumberTitle', 'off', 'Name', 'Classification Map')
imagesc(pred1);
axis off
set(gcf, 'position', [400 400 300 400]);
end
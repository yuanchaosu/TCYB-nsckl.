function [Para] = HyParameters(test)
%%   This function can set the hyperparameters for NSCKL.
%%
% gamma0 for GKF neighborhood
% winw neighborhood window width 
% clus for indian clus = 60
% n_randompixels anchors
% T interative stop condition
% lambad0 = 50; % iterative filter parameter for the vertexes of the graph
%
% Authors: Yuanchao Su, Mengying Jiang, Lianru Gao, Antonio Plaza, Xu Sun, and Bing Zhang.
% Beijing, China
% 2021
%
% Email(Yuanchao Su): suych3@xust.edu.cn
% Email(Lianru Gao): gaolr@aircas.ac.cn
%%
switch test
   case 1
%% Indian data (classificaion map with testing set)
   Para.gamma0 = 0.3; % for GKF neighborhood
   Para.winw = 5; % neighborhood window width 
   Para.clus = 50; %for indian clus = 60
   Para.n_random_anchors = 100; % anchors
   Para.T = 9;
   Para.lambad0 = 50; % iterative filter parameter for the vertexes of the graph
   case 2
%% Indian data (classificaion map on all pixels)
   Para.gamma0 = 0.3; % for GKF neighborhood
   Para.winw = 5; % neighborhood window width 
   Para.clus = 50; %for indian clus = 60
   Para.n_random_anchors = 100; % anchors
   Para.T = 9;
   Para.lambad0 = 50; % iterative filter parameter for the vertexes of the graph   
 %% Salina data 
   case 3
   Para.gamma0 = 0.2; % for GKF neighborhood
   Para.winw = 11; % neighborhood window width 
   Para.clus = 30; %for indian clus = 60
   Para.n_random_anchors = 50; % anchors
   Para.T = 9;
   Para.lambad0 = 50;          
%% Houston data (classificaion map with testing set)
   case 4
   Para.gamma0 = 0.2; % for GKF neighborhood
   Para.winw = 5; % neighborhood window width 
   Para.clus = 30; 
   Para.n_random_anchors = 0; % anchors
   Para.T = 9;
   Para.lambad0 = 50; 
%% Houston data (classificaion map on all pixels)
   case 5
   Para.gamma0 = 0.2; % for GKF neighborhood
   Para.winw = 5; % neighborhood window width 
   Para.clus = 30; 
   Para.n_random_anchors = 0; % anchors
   Para.T = 9;
   Para.lambad0 = 50; 
   
%% WUHAN LongKou/HongHu data test
   case 6
%        % WuHan LongKou
%    Para.gamma0 = 0.2; % for GKF neighborhood
%    Para.winw = 5; % neighborhood window width 
%    Para.clus = 30; %for indian clus = 60
%    Para.n_randompixels = 50; % anchors
%    Para.T = 9;
%    Para.lambad0 = 50; 
%    case 6
       % WuHan HongHu
   Para.gamma0 = 0.2; % for GKF neighborhood
   Para.winw = 11; % neighborhood window width 
   Para.clus = 30; %for indian clus = 60
   Para.n_random_anchors = 50; % anchors
   Para.T = 9;
   Para.lambad0 = 50; 
end

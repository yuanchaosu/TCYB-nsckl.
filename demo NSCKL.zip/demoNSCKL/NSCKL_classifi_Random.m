function [B,labels,pred1,OA1,AA1,kappa1,CA1,TIME] = NSCKL_classifi_Random(image,GT,classifier,...
    clus,winw,gamma0,lambad0,T,n_randompixels,C,sigma0,classnum,runtimes,samp_perc,Accuracy,ShowB)
% Input--------------------------------------------------------------------
% image: r*c*bands
% GT: ground truth
% Accuracy: Using 'yes' to implement accuracy calculation.
% Accuracy: Using 'no', all pixels will get their labels. The accuracy will
% be "0".
% ShowB: 'yes' display clustered features
% Output-------------------------------------------------------------------
% B: clustered features matrix.
% labels
% pred1: classification map.
% OA, AA, Kappa, and CA
% -------------------------------------------------------------------------
% This function was made by Yuanchao Su, Mengying Jiang, Lianru Gao and Antonio Plaza.
% Apri. 2021
% Email: suych3@xust.edu.cn (or suych3@mail2.sysu.edu.cn)
% -------------------------------------------------------------------------
[nr,nc,dim] = size(image);
nall = nr*nc;
data = reshape(image,nall,dim);
data = normalized(data); % normailization
lambad0 = lambad0/nall;
% NSCKL for feature learning
tstart = tic;
[~,B] = NSCKL(data,'CLUS_NUM',clus,'WINDIW_WIDTH',winw,'HSI_ROWS',nr,'GKF_PARA',gamma0,'ITERATION_PARA',T,'STOPCONDI',lambad0,'ANCHOR_NODES',n_randompixels);
% B=U(:,1:60);
OA1 = zeros(runtimes,1); kappa1 = zeros(runtimes,1); AA1 = zeros(runtimes,1); CA1 = zeros(classnum,runtimes);
%%
runs =0;
switch classifier
% KELM is used for classifier.
    case 'KELM'
        fprintf('Using KELM as classifier...')
% After 10n iterations, training samples were randomly obtained each time to obtain 
% the results of ten times, and the standard deviation was directly averaged.
    for j = 1:runtimes
        runs = runs +1;
        disp(['run times' num2str(runs) '/' num2str(runtimes)]);
        [~, labels, indexs] = trainsamples(image,GT,classnum,samp_perc); 
% Get the index and labels of the training sample.
        [~, testLabels, testIndexs,~,~] = testsamples(image,GT,indexs);
% Get the index and labels of the test sample.

% B is the clustering features. 
% B is used for training classification
        XTrn_sc = B(indexs,:);
        XTst_sc = B(testIndexs,:);
% Training Procedure
% Cross-Validation
        [sigma_sc,C_sc] = KELM_CrossValidation(XTrn_sc,labels,C,sigma0);
        if strcmp(Accuracy, 'yes')        
% Testing Procedure
           [pred_sc,~] = KELM(XTrn_sc,XTst_sc,labels',C_sc,sigma_sc);      
            pred1 = zeros(nr,nc);               
            pred1(testIndexs) = pred_sc;
            pred1(indexs) = labels;
        
% Accuracy calculation function
            [OA1(j),kappa1(j),AA1(j),CA1(:,j)] = calcError(testLabels,pred_sc',1:classnum);
        else
% no Accuracy calculation
% If you want to get whole label classification, you can use it. 
            [pred_sc,~] = KELM(XTrn_sc,B,labels',C_sc,sigma_sc); 
             pred1 = zeros(nr,nc);
% If you want to get whole label classification, you can use it.
             pred1(:) = pred_sc; 
        end
        TIME(j)= toc(tstart);
    end
%%
% Multilayer KELM is used for classifier.
    case 'M_KELM'
        fprintf('Using Multilayer KELM as classifier...')
% After 10n iterations, training samples were randomly obtained each time to obtain 
% the results of ten times, and the standard deviation was directly averaged.
for j = 1:runtimes
    tstart = tic;
    runs = runs +1;
    disp(['run times' num2str(runs) '/' num2str(runtimes)]);
% Get the index and labels of the training sample.
    [~, labels, indexs] = trainsamples(image,GT,samp_perc); 
% Get the index and labels of the test sample.
    [~, testLabels, testIndexs,~,~] = testsamples(image,GT,indexs); 
    
    XTrn_sc = B(indexs,:);
%     XTst_sc = B(testIndexs,:);
% Two KELM autoencoders 
    [sigma_sc,C_sc] = M_KELM_CrossValidation(XTrn_sc,labels,C,sigma0);
    [~,p_sc] = M_KELM(B,indexs,testIndexs,labels',C_sc,sigma_sc);
    p = p_sc;
    [~,pred] = max(p);
% Accuracy
    pred1 = zeros(nr,nc);
    pred1(testIndexs)=pred;
    pred1(indexs)=labels;
% Accuracy calculation function    
    [OA1(j),kappa1(j),AA1(j),CA1(:,j)] = calcError(testLabels,pred1(testIndexs),1:classnum); 
    TIME(j)= toc(tstart);
end
end        

%%
% Take the tenth precision, take the mean and the standard deviation.
% OA = mean(OA1);
% std_OA = std(OA1);
% AA = mean(AA1);
% std_AA = std(AA1);
% KAPPA = mean( kappa1);
% std_KAPPA = std( kappa1);
% CA1 = CA1';
% CA = mean(CA1);
% std_CA = std(CA1);

%% showing cluster features
if strcmp(ShowB, 'yes')
    B1 = B';
    [sudim, ~] = size(B1);
    B3d = reshape(B1.', nr, nc, sudim);
    % the number of cluster is set as 60.
    figure('NumberTitle', 'off', 'Name', 'Clustered Features')
    sho = tight_subplot(clus/10,10,[.015, .01],[.1, .015]);
    for i = 1:sudim
        bandimage = B3d(:,:,i);
        axes(sho(i))
        imagesc(bandimage);
%         colormap(jet)
        colormap(gray)
        axis off
    end
end
end


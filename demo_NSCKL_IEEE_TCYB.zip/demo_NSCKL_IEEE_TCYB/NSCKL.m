function [XT,B] = NSCKL(data,varargin)
% User guide:
%%
% This function is about to NSCKL.
% This is the main function of the NSCKL algorithm. 
% Recommendation：Please use MATLAB 2020 or later version to run the function.
% %------------------------------------
% Input:
% data (pixels*bands)
% varargin: see switch.
%--------------------------------------
% output:
% U: eigenvectors
% B: cluster feature matrix.
% Each column is a cluster feature.
%--------------------------------------
% How it's used
% [U,B] = NSCKL_FL(data,'CLUS_NUM',clus,'WINDIW_WIDTH',winw,'HSI_ROWS',nr,'GKF_PARA',gamma0,...
% 'ITERATION_PARA',T,'STOPCONDI',lambad,'ANCHOR_NODES',n_randompixels);
%--------------------------------------
%
% Authors: Yuanchao Su, Mengying Jiang, Lianru Gao, Antonio Plaza, Xu Sun, and Bing Zhang.
% Beijing, China
% 2021
%
% Email(Yuanchao Su): suych3@xust.edu.cn
% Email(Lianru Gao): gaolr@aircas.ac.cn
%--------------------------------------
%%
fprintf('Start NSCKL......')
if (nargin-length(varargin)) ~= 1
    error('Wrong number of required parameters');
elseif (rem(length(varargin),2)==1)
    error('Optional input parameters should always go by pairs');
else
    for i = 1:2:(length(varargin)-1)
        switch upper(varargin{i})
            case 'CLUS_NUM' % number of clusters
                clus = varargin{i+1};
            case 'WINDIW_WIDTH' % window width
                winw = varargin{i+1};
            case 'HSI_ROWS' % rows of HSI (neighborhood)
                nr = varargin{i+1};
            case 'GKF_PARA' % parameter of gaussian kernel function
                gamma0 = varargin{i+1};
            case 'ITERATION_PARA'
                T = varargin{i+1}; % iterative parameter
            case 'STOPCONDI' % parameter of the stop condition
                lambad = varargin{i+1};
            case 'ANCHOR_NODES' % anchor nodes of NSC
                n_random_anchors = varargin{i+1}; % anchor nodes are randomly selected.           
            otherwise
                error(['Unrecognized option: ''' varargin{i} '''']);
        end
    end
end

%% Establishing Vertexes for NSC
[nall,dim]=size(data);
newdata = zeros(T,nall,dim);
if n_random_anchors ~= 0
% sumweivec = zeros(T,1);
% A vertex represents a related characterize from neighboring pixels.
[XT,sum_wei] = spatial_neigh (data,data,winw,nr,gamma0);
newdata(1,:,:) = XT;
nclum = length(sum_wei);
sumweivec = zeros(T,nclum);
sumweivec(1,:) = sum_wei;
% In these neighboring pixels, some are labeled, while some are unlabeled.
[XT,sum_wei] = spatial_neigh (XT,XT,winw,nr,gamma0);
newdata(2,:,:) = XT;
sumweivec(2,:) = sum_wei;
% Iterative adaptive filter (IAF)
% Considering second derivative
for i = 3:T
    [XT,sumweivec(i,:)] = spatial_neigh (XT,XT,winw,nr,gamma0);
    newdata(i,:,:) = XT;
    if(norm(2*sumweivec(i-1,:)-(sumweivec(i-2,:)+sumweivec(i,:)))/nall<lambad)
        %     if(norm(2*sumweivec(i-1,:)-(sumweivec(i-2,:)+sumweivec(i,:)))<lambad)
        break
    end
end
XT = newdata(i-1,:,:);

%% Cutting Graph for NSC
% XT is as the vertexes of graph.
XT = reshape(XT,nall,dim);
pixel_norm = zeros(nall,dim);
for i = 1:nall
    a = norm(XT(i,:));
    pixel_norm(i,:) = XT(i,:)/a;
end
% anchor nodes
index = randperm(nall);
indexs = index(1:n_random_anchors);
random_pixels = pixel_norm(indexs,:);
pixel_norm = pixel_norm*random_pixels';

% consider computer meomory(RAM)
% n_segment is used for segmenting data.
if  nall < 30000 % for small data. For example，Indian Pines data
    % For being suitable for large-scale HSIs.
    % To enhance computational efficiency, adopts inner product to replace GKF.
    similar_matrix = pixel_norm*pixel_norm';   % for the inner product.【n*n】
    degree_matrix = sum(similar_matrix,1);   % Degree matrix
    identity_matrix = ones(nall,1)'; % Identity matrix
    degree_matrix = diag(identity_matrix ./(sqrt(degree_matrix))); %D^-1/2
    % During the cutting graph, the new NSC needs labeled and unlabeled samples
    P = degree_matrix*pixel_norm; % D^-1/2 * X
    
else % for big data

    n_segment=1000;  
    trade = fix(nall/n_segment); % The number of pixels in each segmentation.
    index_begin=1; 
    similar_sum = zeros(nall, 1);
    for j = 1:n_segment
        similar_sum(index_begin:index_begin+trade-1)= sum(pixel_norm(index_begin:index_begin+trade-1,:)*pixel_norm', 2);  % We get the sum of the trade similarities.
        index_begin = j*trade;
    end
    similar_sum(index_begin:nall) = sum(pixel_norm(index_begin:nall,:)*pixel_norm',2);
    similar_sum = sqrt(similar_sum); %  similarity^1/2
    similar_matrix = repmat(similar_sum,1,n_random_anchors); % The original similarity is: n->n*n_randompixels
    P = pixel_norm./similar_matrix;  
%     
%     
%     data_norm = zeros(nall,n_randompixels);
%     for j = 1:n_segment
%         data1 = pixel_norm(index_begin:index_begin+trade-1,:);      
%         degree= sqrt(sum(data1*pixel_norm', 2));       
%         degree_matrix = repmat(degree,1,n_randompixels);       
%         data_norm(index_begin:index_begin+trade-1,:)= data1./degree_matrix;       
%         index_begin = j*trade;       
%     end   
%     data1 = pixel_norm(index_begin:nall,:);
%     degree= sqrt(sum(data1*pixel_norm', 2));   
%     degree_matrix = repmat(degree,1,n_random_anchors);   
%     data_norm(index_begin:nall,:)= data1./degree_matrix;    
%     P = data_norm;
    
end
% singular value decomposition
idx01 = find(isnan(P));
P(idx01) = 0;
idx02 = find(P ==inf);
P(idx02) = 0;

[U, ~, ~] = svd(P,'econ');
% normalization
[U] = normalized(U);
% obtianing eigenvectors
% clus largest eigenvectors
% save U U
B = U(:,1:clus);

else % don't use anchors
   [XT] = spatial_neigh(data,data,winw,nr,gamma0);
   [XT] = spatial_neigh(XT,XT,winw,nr,gamma0);
   n_segment = 1000;
   pixel_norm = zeros(nall, 1);
   similar_sum = zeros(nall, 1);
   for i = 1:nall
       a = norm(XT(i,:));
       pixel_norm(i) = 1/a;
   end
   nrom_matrix = repmat(pixel_norm,1,dim);
   norm_data = nrom_matrix.*XT;
   trade = fix(nall/n_segment);
   index_begin=1;
   for j = 1:n_segment
       similar_sum(index_begin:index_begin+trade-1)= sum(XT(index_begin:index_begin+trade-1,:)*XT', 2);
       index_begin = j*trade;
   end
   similar_sum(index_begin:nall) = sum(XT(index_begin:nall,:)*XT',2);
   similar_matrix = repmat(similar_sum,1,dim);
   P = norm_data./sqrt(similar_matrix);

   idx01 = find(isnan(P));
   P(idx01) = 0;
   idx02 = find(P ==inf);
   P(idx02) = 0;
   [U, ~, ~] =svd(P,'econ');
   B = U(:,1:clus);
end
end


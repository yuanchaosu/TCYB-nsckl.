clc
clear all
close all
currentFolder = pwd;
addpath(genpath(currentFolder))

load Indian % Hyperspectral image
load Indian_gt % Ground Truth

gamma0 = 0.2; % for GKF neighborhood


winw = 5; % neighborhood window width

clus0 = [5,10,20,30,40,50,60,70,80,90,100]; 

n_randompixels = 100; % achor node

T = 8;
lambad0 = 50; % iterative parameter

ShowB = 'yes';

C=[10^0 10^1 10^2 10^3 10^4 10^5]; 
sigma0=[2^(-4),2^(-3),2^(-2),2^(-1),2^(0),2^(1),2^(2),2^(3),2^(4)]; 


classifier = 'KELM';
% classifier = 'M_KELM';


for i = 1:length(clus0)
    clus = clus0(i);
  [B,labels,pred1,OA1,AA1,kappa1,CA1] = NSCKL_classifi_Random(image,GT,classifier,Para.clus,...
    Para.winw,Para.gamma0,Para.lambad0,Para.T,Para.n_randompixels,C,sigma0,classnum,runtimes,...
    samp_perc,'yes','no');
  OA = mean(OA1);
  std_OA = std(OA1);
  AA = mean(AA1);
  std_AA = std(AA1);
  KAPPA = mean( kappa1);
  std_KAPPA = std( kappa1);
  CA1 = CA1';
  CA = mean(CA1);
  std_CA = std(CA1);

  kappa1_t(:,i) = kappa1;
  std_KAPPA_t(:,i) = std_KAPPA;
end











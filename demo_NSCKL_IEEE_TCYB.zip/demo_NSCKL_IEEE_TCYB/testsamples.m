function [images, labels, indexs,tempimg,maxmun] = testsamples(img, gt,trainindexs)
% Acquire test samples.
%%
imgsize = size(img);
num = imgsize(1)*imgsize(2);   
indexs = [];
gt(trainindexs)=0;             

for i = 1 : num                 
    if gt(i) ~= 0
        indexs = [indexs; i];     
    end
end
labels = gt(indexs);
[nr,nc,ndim]=size(img);
nall=nr*nc;
tempimg = reshape(img, nall,ndim);
maxmun=max(tempimg(:));
images = tempimg(indexs,:);
images = double(images'./max(max(tempimg)));
end
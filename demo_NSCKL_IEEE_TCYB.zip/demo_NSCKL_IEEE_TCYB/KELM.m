function [pred,p] = KELM(XTrn,XTst,YTrn,C1,sigma1)
% This function can implement the KELM.
% The file refers to Dr. Yicong Zhou's SSN.
% “Learning hierarchical spectralspatial features for
% hyperspectral image classification,” IEEE Transactions on Cybernetics.
%%
[nTrn,~] = size(XTrn); 
classLabel = unique(YTrn);  nClass = length(classLabel);
temp_T = zeros(nClass, nTrn);
for i = 1 : nTrn
    for j = 1 : nClass
        if classLabel(j) == YTrn(i)
            break;
        end
    end
    temp_T(j,i) = 1;
end
T = temp_T*2 - 1;
clear i j                        
newktrn = kernelFun('rbf', sigma1, XTrn, XTrn);                                 
newktst = kernelFun('rbf', sigma1, XTrn, XTst);
B=(eye(nTrn)./C1 + newktrn)\T';
p=B'*newktst';
[~,pred]=max(p);
end

                                                 

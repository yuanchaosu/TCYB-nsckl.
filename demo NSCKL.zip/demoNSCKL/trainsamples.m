function [images, labels, indexs] = trainsamples(img, gt,classnum,nsec)
indexs = [];
% labels = [];
a=zeros(classnum,1);
for j=1:classnum
    a(j)=length(find(gt==j));
end
for i = 1 : classnum
%      nuse = min(nsec, round(a(i)/2) ); 
      nuse = ceil(a(i)*nsec);
    switch i
        case i
            tempindex = find(gt == i);
            tempindex=tempindex';
            rp=randperm(length(tempindex)); 
            indexs=[indexs tempindex(rp(1: nuse))];

    end
end

labels = gt(indexs);
labels = double(labels);

[nr,nc,ndim]=size(img);
nall=nr*nc;
tempimg=reshape(img,nall,ndim);       
% bandmaxvalue=max(tempimg(:));                          
images = (tempimg(indexs, :))';                       

end
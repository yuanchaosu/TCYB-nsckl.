import numpy as np
import matplotlib.pyplot as plt

colors0 = '#D2691E' # 点的颜色
colors1 = '#00CED1'
colors2 = '#DC143C'
colors3 = '#008000'
colors4 = '#FF1493'
colors5 = '#A9A9A9'
colors6 = '#00008B'
colors7 = '#FFF0F5' # 'lavenderblush'
colors8 = '#48D1CC' # ''blue''
colors9 = '#FF0000' # 'red'

clusters = ['10', '20', '50', '100', '200']
x = range(len(clusters))
y1 = [35.96,37.26,37.82,41.25,41.63]
y2 = [94.79,95.42,98.89,99.02,99.02]

# y1_st = [2.52,3.25,2.09,1.88,2.08]
# y2_st = [0.37,0.43,0.30,0.36,0.15]
# plt.errorbar(x,y1,c=colors8,yerr = y1_st,capsize=5, capthick=1.5)
# plt.errorbar(x,y2,c=colors3,yerr = y2_st,capsize=5, capthick=1.5)

plt.plot(x,y1,c=colors8,marker='^',mec='r', mfc='w',ms=10,label='Unsupervised (FSCAG)',linewidth=2)
plt.plot(x,y2,c=colors3,marker='s',mec='r', mfc='w',ms=10,label='Semisupervised (NSCKL)',linewidth=2)

plt.xlabel("Anchors",fontsize=20)
plt.ylabel("OA (%)",fontsize=20)

plt.legend(loc='best',edgecolor='black',fontsize=20)

plt.xticks(x, clusters, rotation=-45)
plt.tick_params(labelsize=20) #刻度字体大小13
plt.grid(ls = '--')
# plt.margins(0)
# plt.subplots_adjust(bottom=0.5)
plt.savefig('NSCKLFSCAG01.eps',dpi=200, bbox_inches='tight')
plt.savefig('NSCKLFSCAG01.jpg',dpi=200, bbox_inches='tight')
plt.savefig('NSCKLFSCAG01.pdf',dpi=200, bbox_inches='tight')
plt.show()

# plt.savefig('NSCKL_FSCAG01.jpg')

function [newdatas,sum_we] = spatial_neigh(data,dAtaspec,wid,nr,gamma0)
% Get the initial correlations.
%%
w = wid; wc = (w-1)/2;  vv = -wc : wc;
idw0 = repmat(vv*nr,w,1) + repmat(vv',1,w);
idw0 = reshape(idw0,1,w*w);          
[lenth,dim]=size(data);
newdatas=zeros(lenth,dim);
sum_we = [];
for i=1:lenth
    idw = idw0 + i;
    idw(idw>lenth | idw<1) = [];    
    dtmp = repmat(dAtaspec(i,:),length(idw),1) - dAtaspec(idw,:);
    A = sum(dtmp.*dtmp, 2);
    we = exp(-gamma0*A);
    newdatas(i,:) = 1/sum(we) * sum(diag(we)*data(idw,:),1);
    sum_we = horzcat(sum_we,we');
end
end
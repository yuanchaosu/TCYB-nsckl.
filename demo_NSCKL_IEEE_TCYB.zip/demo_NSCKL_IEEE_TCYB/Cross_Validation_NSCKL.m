function [sigma1,C1,SchTime] = Cross_Validation_NSCKL(XTrn,YTrn,C,sigma)
% Cross Validation
%%
[nTrn ,~] = size(XTrn);                            
classLabel = unique(YTrn);  
nClass = length(classLabel);                   
temp_T = zeros(nClass, nTrn);                                              
cgtmp = double(zeros(length(sigma),length(C)));
cg = double(zeros(length(sigma),length(C)));
for i = 1 : nTrn
    for j = 1 : nClass
        if classLabel(j) == YTrn(i)
            break;
        end
    end
    temp_T(j,i) = 1;
end
T = temp_T*2 - 1;
%%
%--------------------------5 cross validations-----------------------------
tstart = tic;
nfold = 5; nSamfold = floor(nTrn/nfold);                                  
nperm = randperm(nTrn);                                                    
for i = 1 : nfold                                                          
    %1:5
    idtst = ((i-1)*nSamfold + 1) : i*nSamfold;                               
    idtrn = 1 : nTrn; idtrn(idtst) = [];                                  
    idtst = nperm(idtst);  
    idtrn = nperm(idtrn);                           
    for p = 1 : length(sigma)          
        s1 = sigma(p);      
            Kw  = kernelFun('rbf', s1, XTrn(idtrn,:), XTrn(idtrn,:));     
            Kwt = kernelFun('rbf', s1, XTrn(idtrn,:),  XTrn(idtst,:));     
            for h = 1 : length(C)                                        
                cc = C(h);                                                                
                OutputWeight = (eye(length(idtrn))/cc + Kw) \ T(:,idtrn)';            
                TY = (Kwt * OutputWeight)';                                 
                [~,B1] = max(TY,[],1); 
% A1 is the maximum value of each column in TY, and B1 is the largest number of rows in each column            
                Ypre_tst = classLabel(B1); 
% B1 transpose from a row vector to a column vector
                cgtmp(p,h) = length(find(YTrn(idtst)==Ypre_tst)) / length(idtst); 
% The precision is obtained by comparing the transposed column vectors with the original matrix        
            end      
    end   
    cg = cg + cgtmp; 
% The accuracy is assigned to cg, accumulated 5 times, and then averaged                                                      
end
cg = cg/nfold;
[A,B]=find(cg==max(max(cg)));
sigma1=sigma(A(1));
C1=C(B(1));
SchTime = toc(tstart);
end


